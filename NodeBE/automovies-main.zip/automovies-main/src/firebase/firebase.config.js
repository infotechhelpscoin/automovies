// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCI32T7hOw3QTv89gI7BJVcm230xJXWcCM",
  authDomain: "automovies-19743.firebaseapp.com",
  projectId: "automovies-19743",
  storageBucket: "automovies-19743.appspot.com",
  messagingSenderId: "1030926144519",
  appId: "1:1030926144519:web:19f0772de3d0a9fbdb86a2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;